-- ============================================================================
--  ZAHARA — Tabela de ATACADO (pedidos a partir de 4 unidades)
--  Regra: atacado = varejo × 0,80, arredondado para R$ inteiro.
--  Gerado em 04/09/2026 a partir dos 108 produtos publicados em zaharacg.com.br.
--
--  COMO USAR (Supabase ▸ SQL Editor ▸ New query):
--   1) Rode o PASSO 1 sozinho e confira a prévia (nada é alterado).
--   2) Se estiver ok, rode o PASSO 2 (aplica) e o PASSO 3 (ajuste de cadastro).
--  O catálogo público atualiza na hora; não precisa republicar o site.
-- ============================================================================

-- PASSO 1 — PRÉVIA: compara o atacado atual com o novo, sem alterar nada -------
with novos(marca, nome, varejo_ref, atacado_antigo, atacado_novo) as (
 values
  ('Al Wataniah', 'Sabah Al Ward', 145, 130, 116),
  ('ARMAF', 'Club de Nuit Intense Man', 279, 255, 223),
  ('ARMAF', 'Club de Nuit Milestone', 255, 240, 204),
  ('French Avenue', 'Liquid Brun', 275, 260, 220),
  ('French Avenue', 'Vulcan Feu', 325, 275, 260),
  ('Lattafa', 'Ajwad', 145, 130, 116),
  ('Lattafa', 'Al Nashama Caprice', 175, 160, 140),
  ('Lattafa', 'Al Noble Ameer', 155, 140, 124),
  ('Lattafa', 'Al Noble Safeer', 155, 140, 124),
  ('Lattafa', 'Ana Abiyedh', 165, 150, 132),
  ('Lattafa', 'Ana Abiyedh Coral', 129, 114, 103),
  ('Lattafa', 'Ana Abiyedh Leather', 145, 130, 116),
  ('Lattafa', 'Ana Abiyedh Rouge', 155, 140, 124),
  ('Lattafa', 'Art Of Arabia I', 225, 210, 180),
  ('Lattafa', 'Art Of Nature I', 229, 214, 183),
  ('Lattafa', 'Art Of Universe', 215, 200, 172),
  ('Lattafa', 'Asad Black', 249, 179, 199),
  ('Lattafa', 'Asad Bourbon', 289, 225, 231),
  ('Lattafa', 'Asad Elixir', 209, 194, 167),
  ('Lattafa', 'Asad Limited Edition', 205, 190, 164),
  ('Lattafa', 'Atheeri', 355, 340, 284),
  ('Lattafa', 'Atlas', 179, 164, 143),
  ('Lattafa', 'Bade''e Al Oud Honor & Glory (Branco)', 165, 150, 132),
  ('Lattafa', 'Bade''e Al Oud Noble Blush (Rosa)', 165, 150, 132),
  ('Lattafa', 'Bade''e Al Oud Preto (Oud for Glory)', 159, 144, 127),
  ('Lattafa', 'Dalal', 289, 274, 231),
  ('Lattafa', 'Dream of Haze', 240, 225, 192),
  ('Lattafa', 'Eclaire Banoffi', 209, 194, 167),
  ('Lattafa', 'Eclaire Pistache', 225, 210, 180),
  ('Lattafa', 'Emeer', 229, 214, 183),
  ('Lattafa', 'Eternal Oud', 189, 174, 151),
  ('Lattafa', 'Fakhar Black', 195, 180, 156),
  ('Lattafa', 'Fakhar Gold', 159, 144, 127),
  ('Lattafa', 'Fakhar Platinum', 180, 165, 144),
  ('Lattafa', 'Fakhar Rose', 215, 200, 172),
  ('Lattafa', 'Give Me Gourmand Berry On Top', 255, 240, 204),
  ('Lattafa', 'Give Me Gourmand Mallow Madness', 315, 300, 252),
  ('Lattafa', 'Give Me Gourmand Vanilla Freak', 315, 300, 252),
  ('Lattafa', 'Give Me Gourmand Whipped Pleasure', 315, 300, 252),
  ('Lattafa', 'Haya', 265, 250, 212),
  ('Lattafa', 'Hayaat Black', 170, 155, 136),
  ('Lattafa', 'Hayaat Gold Elixir', 135, 120, 108),
  ('Lattafa', 'Her Confession', 205, 190, 164),
  ('Lattafa', 'Ishq Al Shuyukh Gold', 169, 154, 135),
  ('Lattafa', 'Ishq Al Shuyukh Silver', 205, 190, 164),
  ('Lattafa', 'Jasoor', 179, 164, 143),
  ('Lattafa', 'Khamrah Dukhan', 205, 190, 164),
  ('Lattafa', 'Khamrah EDP', 255, 190, 204),
  ('Lattafa', 'Khamrah Qahwa', 180, 165, 144),
  ('Lattafa', 'Khanjar', 280, 265, 224),
  ('Lattafa', 'King Of Arabia', 245, 230, 196),
  ('Lattafa', 'Maahir Legacy', 175, 160, 140),
  ('Lattafa', 'Mayar Natural Intense', 165, 150, 132),
  ('Lattafa', 'Mayar Rosa', 165, 150, 132),
  ('Lattafa', 'Musamam White Intense', 265, 250, 212),
  ('Lattafa', 'Najdia Intense', 155, 140, 124),
  ('Lattafa', 'Nebras', 195, 180, 156),
  ('Lattafa', 'Nebras Elixir', 205, 190, 164),
  ('Lattafa', 'Opulent Dubai', 165, 150, 132),
  ('Lattafa', 'Petra', 179, 164, 143),
  ('Lattafa', 'Pisa', 249, 234, 199),
  ('Lattafa', 'Pure Crystal', 370, 355, 296),
  ('Lattafa', 'Qaed Al Fursan Black', 145, 130, 116),
  ('Lattafa', 'Qaed Al Fursan Brown', 140, 125, 112),
  ('Lattafa', 'Qaed Al Fursan White', 140, 125, 112),
  ('Lattafa', 'Queen Of Arabia', 345, 330, 276),
  ('Lattafa', 'Raneen', 215, 200, 172),
  ('Lattafa', 'Sakeena', 159, 144, 127),
  ('Lattafa', 'Sehr', 200, 185, 160),
  ('Lattafa', 'Shaheen Silver', 169, 154, 135),
  ('Lattafa', 'Teriaq', 210, 195, 168),
  ('Lattafa', 'Tharwah Gold', 315, 300, 252),
  ('Lattafa', 'Tharwah Silver', 229, 214, 183),
  ('Lattafa', 'The Kingdom Masculino', 209, 194, 167),
  ('Lattafa', 'Velvet Oud', 145, 130, 116),
  ('Lattafa', 'Victoria', 189, 174, 151),
  ('Lattafa', 'Vintage Radio', 179, 164, 143),
  ('Lattafa', 'Yara Candy', 165, 150, 132),
  ('Lattafa', 'Yara Elixir', 205, 190, 164),
  ('Lattafa', 'Yara Moi', 165, 150, 132),
  ('Lattafa', 'Yara Rosa', 175, 160, 140),
  ('Maison Alhambra', 'Alpine', 185, 150, 148),
  ('Maison Alhambra', 'Athena', 265, 230, 212),
  ('Maison Alhambra', 'Avant', 175, 140, 140),
  ('Maison Alhambra', 'Bad Femme', 185, 150, 148),
  ('Maison Alhambra', 'Bad Homme', 199, 164, 159),
  ('Maison Alhambra', 'Camille For Women', 185, 150, 148),
  ('Maison Alhambra', 'Chants', 179, 144, 143),
  ('Maison Alhambra', 'Como Moiselle', 179, 164, 143),
  ('Maison Alhambra', 'Daring Blue', 175, 140, 140),
  ('Maison Alhambra', 'Delilah Blanc', 265, 230, 212),
  ('Maison Alhambra', 'Delilah Rosa', 209, 174, 167),
  ('Maison Alhambra', 'Galact Men Elixir', 149, 114, 119),
  ('Maison Alhambra', 'Galact Men Intense', 149, 114, 119),
  ('Maison Alhambra', 'Glacier Bella', 185, 150, 148),
  ('Maison Alhambra', 'Glacier Gold', 175, 140, 140),
  ('Maison Alhambra', 'Glacier Pour Homme', 185, 150, 148),
  ('Maison Alhambra', 'Intrude', 185, 150, 148),
  ('Maison Alhambra', 'Jorge de Profumo aqua', 185, 150, 148),
  ('Maison Alhambra', 'Jorge de Profumo Black', 189, 154, 151),
  ('Maison Alhambra', 'Jorge de Profumo Deep Blue', 189, 154, 151),
  ('Maison Alhambra', 'Kingsman', 175, 140, 140),
  ('Maison Alhambra', 'La Rouge Baroque Extreme', 189, 154, 151),
  ('Maison Alhambra', 'La Rouge Baroque Tradicional', 179, 144, 143),
  ('Maison Alhambra', 'La Vivacite', 179, 144, 143),
  ('Maison Alhambra', 'La Vivacite Intensa', 175, 140, 140),
  ('Maison Alhambra', 'La Voie', 179, 144, 143),
  ('Maison Alhambra', 'Leonie Tradicional', 199, 164, 159)
)
select p.marca, p.nome,
       p.preco_varejo      as varejo_no_banco,
       n.varejo_ref        as varejo_usado_no_calculo,
       p.preco_atacado     as atacado_atual,
       n.atacado_novo,
       n.atacado_novo - p.preco_atacado as diferenca,
       case when p.preco_varejo <> n.varejo_ref then 'VAREJO MUDOU: revisar' else '' end as alerta
from public.perfumes p
join novos n on lower(p.marca) = lower(n.marca) and lower(p.nome) = lower(n.nome)
order by p.marca, p.nome;

-- Produtos do banco que NÃO estão na lista (cadastrados depois de 04/09/2026):
-- select marca, nome, preco_varejo, preco_atacado from public.perfumes p
-- where not exists (select 1 from (values ('Al Wataniah','Sabah Al Ward'), ('ARMAF','Club de Nuit Intense Man'), ('ARMAF','Club de Nuit Milestone'), ('French Avenue','Liquid Brun'), ('French Avenue','Vulcan Feu'), ('Lattafa','Ajwad'), ('Lattafa','Al Nashama Caprice'), ('Lattafa','Al Noble Ameer'), ('Lattafa','Al Noble Safeer'), ('Lattafa','Ana Abiyedh'), ('Lattafa','Ana Abiyedh Coral'), ('Lattafa','Ana Abiyedh Leather'), ('Lattafa','Ana Abiyedh Rouge'), ('Lattafa','Art Of Arabia I'), ('Lattafa','Art Of Nature I'), ('Lattafa','Art Of Universe'), ('Lattafa','Asad Black'), ('Lattafa','Asad Bourbon'), ('Lattafa','Asad Elixir'), ('Lattafa','Asad Limited Edition'), ('Lattafa','Atheeri'), ('Lattafa','Atlas'), ('Lattafa','Bade''e Al Oud Honor & Glory (Branco)'), ('Lattafa','Bade''e Al Oud Noble Blush (Rosa)'), ('Lattafa','Bade''e Al Oud Preto (Oud for Glory)'), ('Lattafa','Dalal'), ('Lattafa','Dream of Haze'), ('Lattafa','Eclaire Banoffi'), ('Lattafa','Eclaire Pistache'), ('Lattafa','Emeer'), ('Lattafa','Eternal Oud'), ('Lattafa','Fakhar Black'), ('Lattafa','Fakhar Gold'), ('Lattafa','Fakhar Platinum'), ('Lattafa','Fakhar Rose'), ('Lattafa','Give Me Gourmand Berry On Top'), ('Lattafa','Give Me Gourmand Mallow Madness'), ('Lattafa','Give Me Gourmand Vanilla Freak'), ('Lattafa','Give Me Gourmand Whipped Pleasure'), ('Lattafa','Haya'), ('Lattafa','Hayaat Black'), ('Lattafa','Hayaat Gold Elixir'), ('Lattafa','Her Confession'), ('Lattafa','Ishq Al Shuyukh Gold'), ('Lattafa','Ishq Al Shuyukh Silver'), ('Lattafa','Jasoor'), ('Lattafa','Khamrah Dukhan'), ('Lattafa','Khamrah EDP'), ('Lattafa','Khamrah Qahwa'), ('Lattafa','Khanjar'), ('Lattafa','King Of Arabia'), ('Lattafa','Maahir Legacy'), ('Lattafa','Mayar Natural Intense'), ('Lattafa','Mayar Rosa'), ('Lattafa','Musamam White Intense'), ('Lattafa','Najdia Intense'), ('Lattafa','Nebras'), ('Lattafa','Nebras Elixir'), ('Lattafa','Opulent Dubai'), ('Lattafa','Petra'), ('Lattafa','Pisa'), ('Lattafa','Pure Crystal'), ('Lattafa','Qaed Al Fursan Black'), ('Lattafa','Qaed Al Fursan Brown'), ('Lattafa','Qaed Al Fursan White'), ('Lattafa','Queen Of Arabia'), ('Lattafa','Raneen'), ('Lattafa','Sakeena'), ('Lattafa','Sehr'), ('Lattafa','Shaheen Silver'), ('Lattafa','Teriaq'), ('Lattafa','Tharwah Gold'), ('Lattafa','Tharwah Silver'), ('Lattafa','The Kingdom Masculino'), ('Lattafa','Velvet Oud'), ('Lattafa','Victoria'), ('Lattafa','Vintage Radio'), ('Lattafa','Yara Candy'), ('Lattafa','Yara Elixir'), ('Lattafa','Yara Moi'), ('Lattafa','Yara Rosa'), ('Maison Alhambra','Alpine'), ('Maison Alhambra','Athena'), ('Maison Alhambra','Avant'), ('Maison Alhambra','Bad Femme'), ('Maison Alhambra','Bad Homme'), ('Maison Alhambra','Camille For Women'), ('Maison Alhambra','Chants'), ('Maison Alhambra','Como Moiselle'), ('Maison Alhambra','Daring Blue'), ('Maison Alhambra','Delilah Blanc'), ('Maison Alhambra','Delilah Rosa'), ('Maison Alhambra','Galact Men Elixir'), ('Maison Alhambra','Galact Men Intense'), ('Maison Alhambra','Glacier Bella'), ('Maison Alhambra','Glacier Gold'), ('Maison Alhambra','Glacier Pour Homme'), ('Maison Alhambra','Intrude'), ('Maison Alhambra','Jorge de Profumo aqua'), ('Maison Alhambra','Jorge de Profumo Black'), ('Maison Alhambra','Jorge de Profumo Deep Blue'), ('Maison Alhambra','Kingsman'), ('Maison Alhambra','La Rouge Baroque Extreme'), ('Maison Alhambra','La Rouge Baroque Tradicional'), ('Maison Alhambra','La Vivacite'), ('Maison Alhambra','La Vivacite Intensa'), ('Maison Alhambra','La Voie'), ('Maison Alhambra','Leonie Tradicional')) as l(marca,nome)
--                   where lower(l.marca)=lower(p.marca) and lower(l.nome)=lower(p.nome));


-- PASSO 2 — APLICAR: grava o novo atacado -----------------------------------------
-- Usa o varejo que está no banco HOJE (não o de referência), então se você
-- reajustou algum varejo depois de 04/09, o atacado sai coerente mesmo assim.
update public.perfumes
set preco_atacado = round(preco_varejo * 0.80);

-- Se preferir NÃO subir o atacado de quem hoje está abaixo da regra
-- (Asad Black 179→199, Asad Bourbon 225→231, Khamrah EDP 190→204,
--  Galact Men Elixir/Intense 114→119), use esta versão no lugar da de cima:
-- update public.perfumes
-- set preco_atacado = least(preco_atacado, round(preco_varejo * 0.80));


-- PASSO 3 — AJUSTES DE CADASTRO encontrados na leitura do site -----------------
update public.perfumes set tamanho = '100ml'
where lower(marca) = 'lattafa' and lower(nome) = 'asad black' and tamanho = '100';


-- CONFERÊNCIA FINAL ---------------------------------------------------------------
select marca, nome, preco_varejo, preco_atacado,
       round((1 - preco_atacado / nullif(preco_varejo,0)) * 100) as desconto_pct
from public.perfumes
order by marca, nome;
