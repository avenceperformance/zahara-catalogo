﻿var SUPABASE_URL = "https://yirdasbxwnbstgpzkuts.supabase.co";
var SUPABASE_ANON_KEY = "sb_publishable_QAmqCHKrHsz_0EQBfYIkbg_W8Vuj48O";