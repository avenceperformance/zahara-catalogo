# Catálogo Zahara Perfumes Árabes — Supabase + Vercel

Duas telas:
- **index.html** → catálogo público (cliente abre, sem login)
- **admin.html** → painel com login pra cadastrar/editar perfumes e subir fotos

Banco, login e fotos ficam no **Supabase**. O site fica na **Vercel**.

---

## PARTE 1 — Supabase (uma vez só)

1. Entre em **supabase.com** → crie um projeto novo (ex.: `zahara`). Guarde a senha do banco.
2. Menu lateral **SQL Editor** → **New query** → cole TODO o conteúdo de `schema.sql` → **Run**.
   Isso cria a tabela de perfumes, as regras de segurança e a pasta de fotos.
3. Menu **Authentication ▸ Users ▸ Add user** → crie seu login (e-mail + senha).
   Esse é o usuário que vai entrar no painel.
4. (Recomendado) **Authentication ▸ Providers ▸ Email** → desligue *"Allow new users to sign up"*.
   Assim só você tem acesso ao painel.
5. Menu **Settings ▸ API** → copie:
   - **Project URL**
   - **anon public** key
   Cole os dois em `supabase-config.js` (nas linhas indicadas).

---

## PARTE 2 — GitHub

Suba para o repositório `zahara-catalogo` os arquivos:
- `index.html`
- `admin.html`
- `supabase-config.js`  (já com URL e key preenchidos)
- `vercel.json`

(O `schema.sql`, a pasta `sql/` e este README não precisam ir, mas não atrapalham.)

> No GitHub: botão **Add file ▸ Upload files** → arraste os arquivos → **Commit**.

---

## PARTE 3 — Vercel

1. Entre em **vercel.com**, login com o GitHub.
2. **Add New… ▸ Project** → escolha `zahara-catalogo` → **Deploy**.
3. Sai a URL pública, ex.:
   - Catálogo (cliente):  `https://zahara-catalogo.vercel.app`
   - Painel (você):       `https://zahara-catalogo.vercel.app/admin`

---

## Uso no dia a dia

- Cadastrar perfume → abra `/admin`, faça login, **＋ Novo perfume**, preencha e salve.
- O catálogo do cliente atualiza **na hora** (puxa direto do Supabase, sem republicar nada).
- Esgotou? Use o 👁 pra ocultar sem apagar. Voltou? Mostra de novo.

## Ajustes no topo do `index.html` (bloco "CONFIG DA LOJA")
- `WHATSAPP` → número que recebe os pedidos. Atual: `5567992890249`
- `MIN_ATACADO` → unidades mínimas pro atacado. Atual: `4`
- `META_PIXEL_ID` → ID do Pixel do Meta (só números). Vazio = pixel desligado.
  Com o ID preenchido o site dispara: `PageView`, `AddToCart` (adicionar ao pedido),
  `InitiateCheckout` (abrir o pedido), `Contact` (qualquer clique pra WhatsApp) e os
  eventos personalizados `PedidoWhatsApp`, `CliqueWhatsApp` e `AvisarEstoque`.
- `SAUDACAO` → texto que abre o WhatsApp nos botões "Pedir pelo WhatsApp" / botão fixo.

## Links pra usar nos anúncios
O site lê parâmetros da URL e já abre filtrado:
- `?q=asad` → busca preenchida (ex.: `https://www.zaharacg.com.br/?q=asad%20black`)
- `?marca=Lattafa` → filtro de marca
- `?cat=Feminino` → categoria (só aparece se os produtos tiverem "Categoria" preenchida no painel)
- `?modo=atacado` → abre direto na tabela de atacado

UTMs chegam até a mensagem do WhatsApp. Exemplo de link de anúncio:
`https://www.zaharacg.com.br/?q=club%20de%20nuit&utm_source=meta&utm_campaign=entrega-hoje&utm_content=video-01`
A mensagem enviada termina com `Origem: meta / entrega-hoje / video-01`, então dá pra saber
de qual anúncio veio cada pedido sem depender do relatório do Meta.

## Preços de atacado (4+ unidades)
A regra adotada é **atacado = varejo − 20%**, arredondado pra real inteiro.
Pra aplicar em todos os produtos de uma vez: `sql/atacado_20pct.sql` (Supabase ▸ SQL Editor).
O arquivo tem uma prévia (não altera nada) e depois o comando que aplica.
Produto novo cadastrado pelo painel: preencha o atacado com `varejo × 0,80`.

## Categorias Masculino/Feminino
O filtro de categoria do site só aparece quando pelo menos um produto tem "Categoria" preenchida
no painel. Hoje o banco publicado não tem esse campo preenchido; ao preencher, o filtro liga sozinho.
