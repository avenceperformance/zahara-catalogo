-- ============================================================================
--  ZAHARA PERFUMES ÁRABES — Estrutura do banco (Supabase)
--  Cole TODO este conteúdo no SQL Editor do Supabase e clique RUN.
-- ============================================================================

-- 1) TABELA DE PERFUMES ------------------------------------------------------
create table if not exists public.perfumes (
  id            uuid primary key default gen_random_uuid(),
  marca         text not null,
  nome          text not null,
  tamanho       text,
  notas         text,
  preco_varejo  numeric(10,2) not null default 0,
  preco_atacado numeric(10,2) not null default 0,
  img_url       text,
  disponivel    boolean not null default true,
  ordem         int not null default 0,
  created_at    timestamptz not null default now(),
  -- campos usados pelo painel (admin.html) e pelo catálogo
  genero             text,        -- 'Masculino' | 'Feminino'
  esgotado           boolean not null default false,
  familia_olfativa   text,
  notas_principais   text,
  recomendacao_uso   text         -- 'Diurno' | 'Noturno' | 'Diurno e Noturno'
);

-- 1b) BANCO JÁ EXISTENTE? Garante as colunas acima sem apagar nada -------------
alter table public.perfumes add column if not exists genero            text;
alter table public.perfumes add column if not exists esgotado          boolean not null default false;
alter table public.perfumes add column if not exists familia_olfativa  text;
alter table public.perfumes add column if not exists notas_principais  text;
alter table public.perfumes add column if not exists recomendacao_uso  text;

-- 2) ROW LEVEL SECURITY ------------------------------------------------------
alter table public.perfumes enable row level security;

-- Leitura liberada para todo mundo (o catálogo público precisa ler)
drop policy if exists "perfumes_leitura_publica" on public.perfumes;
create policy "perfumes_leitura_publica"
  on public.perfumes for select
  using (true);

-- Escrita (cadastrar/editar/excluir) só para quem está LOGADO
drop policy if exists "perfumes_insert_logado" on public.perfumes;
create policy "perfumes_insert_logado"
  on public.perfumes for insert to authenticated
  with check (true);

drop policy if exists "perfumes_update_logado" on public.perfumes;
create policy "perfumes_update_logado"
  on public.perfumes for update to authenticated
  using (true);

drop policy if exists "perfumes_delete_logado" on public.perfumes;
create policy "perfumes_delete_logado"
  on public.perfumes for delete to authenticated
  using (true);

-- 3) STORAGE DAS FOTOS -------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('perfumes', 'perfumes', true)
on conflict (id) do nothing;

-- Qualquer um vê as fotos
drop policy if exists "fotos_leitura_publica" on storage.objects;
create policy "fotos_leitura_publica"
  on storage.objects for select
  using (bucket_id = 'perfumes');

-- Só logado sobe / troca / apaga foto
drop policy if exists "fotos_insert_logado" on storage.objects;
create policy "fotos_insert_logado"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'perfumes');

drop policy if exists "fotos_update_logado" on storage.objects;
create policy "fotos_update_logado"
  on storage.objects for update to authenticated
  using (bucket_id = 'perfumes');

drop policy if exists "fotos_delete_logado" on storage.objects;
create policy "fotos_delete_logado"
  on storage.objects for delete to authenticated
  using (bucket_id = 'perfumes');

-- ============================================================================
--  Pronto. Depois de rodar:
--   • Authentication ▸ Users ▸ Add user  → crie seu login (e-mail + senha)
--   • Authentication ▸ Providers ▸ Email → desligue "Allow new users to sign up"
--     (assim ninguém além de você cria conta)
-- ============================================================================
